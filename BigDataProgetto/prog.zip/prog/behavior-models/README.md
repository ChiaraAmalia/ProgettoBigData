This repository contains information related to experiments on CASAS project of the Washington State University (http://ailab.wsu.edu/casas/datasets.html) for the extration of behavior models. The discovered macro activity models are as follows:

* Desk activity
* Guest bathroom activity
* Kitchen activity
* Master bathroom
* Master bedroom
* Meditater
* Read

The file "petrinet_v1.png" contains the Petri net of the Daily Behavior process model obtained with a threshold valueof 0.20 of the Infrequent Inductive Miner.
